describe('Login account', () => {
    it('Verify that login with account is nor registered', () => {
      cy.visit('https://parabank.parasoft.com/parabank/index.htm');
      cy.get('input[name="username"]').type('sugito');
      cy.get('input[name="password"]').type('sugito');
      cy.get('[type="submit"][value="Log In"]').click();
      cy.contains('An internal error has occurred and has been logged.');
    })

    it('Verify that login with wrong password', () => {
        cy.visit('https://parabank.parasoft.com/parabank/index.htm');
        cy.get('input[name="username"]').type('avinda');
        cy.get('input[name="password"]').type('98765');
        cy.get('[type="submit"][value="Log In"]').click();
        cy.contains('An internal error has occurred and has been logged.');
      })

      it('Verify that login with wrong username', () => {
        cy.visit('https://parabank.parasoft.com/parabank/index.htm');
        cy.get('input[name="username"]').type('avinda');
        cy.get('input[name="password"]').type('98765');
        cy.get('[type="submit"][value="Log In"]').click();
        cy.contains('An internal error has occurred and has been logged.');
      })

})