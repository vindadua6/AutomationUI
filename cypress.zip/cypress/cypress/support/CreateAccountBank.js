describe('Create Account Bank', () => {
    it('Login to system', () => {
      cy.visit('https://parabank.parasoft.com/parabank/index.htm');
      cy.get('input[name="username"]').type('avindaa');
      cy.get('input[name="password"]').type('anjarwatii');
      cy.get('[type="submit"][value="Log In"]').click();
      cy.contains('Welcome Avindaa Anjarwatii');
      cy.contains('Open New Account').click();
      cy.get('#type').select('CHECKING')
      cy.get('#type').should('have.value', '0')
      cy.get('#fromAccountId').select('19005')
      cy.get('#fromAccountId').should('have.value', '19005')
      cy.get('[type="submit"][value="Open New Account"]').click();
      cy.contains("Account Opened");
    })
})