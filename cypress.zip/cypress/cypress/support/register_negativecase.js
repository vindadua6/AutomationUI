describe('Register account with negative case', () => {
 it('Verify register account with missing required parameters', () => {
    //visit website
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    //check register link is not broken
    cy.contains('Register').click();
    cy.get('input[name="customer.firstName"]').type('Ahmad');
    cy.get('input[name="customer.lastName"]').type('Wildan');
    cy.get('input[name="customer.address.street"]').type('Surabaya');
    cy.get('input[name="customer.address.city"]').type('Surabaya');
    cy.get('input[name="customer.address.state"]').type('Surabaya');
    cy.get('input[name="customer.address.zipCode"]').type('1234');
    cy.get('input[name="customer.phoneNumber"]').type('0812345234');
    cy.get('input[name="customer.ssn"]').type('001');
    cy.get('[type="submit"][value="Register"]').click();
    cy.get('span[id="customer.username.errors').contains('Username is required');
    cy.get('span[id="customer.password.errors').contains('Password is required');
    cy.get('span[id="repeatedPassword.errors').contains('Password confirmation is required');
  })
 
  it('Check system behavior when input password not match', () => {
    //visit website
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    //check register link is not broken
    cy.contains('Register').click();
    cy.get('input[name="customer.firstName"]').type('Raka');
    cy.get('input[name="customer.lastName"]').type('Wildan');
    cy.get('input[name="customer.address.street"]').type('Surabaya');
    cy.get('input[name="customer.address.city"]').type('Surabaya');
    cy.get('input[name="customer.address.state"]').type('Surabaya');
    cy.get('input[name="customer.address.zipCode"]').type('1234');
    cy.get('input[name="customer.phoneNumber"]').type('0812345234');
    cy.get('input[name="customer.ssn"]').type('001');
    cy.get('input[name="customer.username"]').type('rakawildan');
    cy.get('input[name="customer.password"]').type('raka');
    cy.get('input[id="repeatedPassword"]').type('12345')
    cy.get('[type="submit"][value="Register"]').click();
    cy.get('span[id="repeatedPassword.errors').contains('Passwords did not match');
  })

  it('Check system behavior when register account use the same data', () => {
    //visit website
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    //check register link is not broken
    cy.contains('Register').click();
    cy.get('input[name="customer.firstName"]').type('Avindaa');
    cy.get('input[name="customer.lastName"]').type('Anjarwatii');
    cy.get('input[name="customer.address.street"]').type('Surabaya');
    cy.get('input[name="customer.address.city"]').type('Surabaya');
    cy.get('input[name="customer.address.state"]').type('Surabaya');
    cy.get('input[name="customer.address.zipCode"]').type('5678');
    cy.get('input[name="customer.phoneNumber"]').type('0812345234');
    cy.get('input[name="customer.ssn"]').type('001');
    cy.get('input[name="customer.username"]').type('avindaa');
    cy.get('input[name="customer.password"]').type('anjarwatii');
    cy.get('input[id="repeatedPassword"]').type('anjarwatii');
    cy.get('[type="submit"][value="Register"]').click();
  })

})