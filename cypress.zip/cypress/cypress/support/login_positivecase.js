describe('Login account', () => {
    it('Verify that login is work as expected', () => {
      cy.visit('https://parabank.parasoft.com/parabank/index.htm');
      cy.get('input[name="username"]').type('avindaa');
      cy.get('input[name="password"]').type('anjarwatii');
      cy.get('[type="submit"][value="Log In"]').click();
      cy.contains('Welcome Avindaa Anjarwatii');
    })
})