const { defineConfig } = require('cypress')

module.exports = defineConfig({

    e2e: {

        baseUrl : 'https://parabank.parasoft.com/parabank/index.htm',
        defaultCommandTimeout: 80000,
        specPattern : "cypress/support",

        supportFile : false,

    },

})